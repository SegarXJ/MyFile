package com.ms08067.getMethods;
import java.lang.reflect.Method;

public class
getDeclaredMethods {
    public static void main(String[] args) throws ClassNotFoundException {

        Class<?> name = Class.forName("java.lang.Runtime");

       Method[] declareMethods = name.getDeclaredMethods();

        System.out.println("通过 getDeclaredMethods 方式获取方法：");
        for(Method m:declareMethods)
            System.out.println(m);
    }
}
