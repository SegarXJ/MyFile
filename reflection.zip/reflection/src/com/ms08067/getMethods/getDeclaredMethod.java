package com.ms08067.getMethods;
import java.lang.reflect.Method;

public class getDeclaredMethod {
    public static void main(String[] args) throws NoSuchMethodException {
        Runtime rt = Runtime.getRuntime();
        Class<?> name = rt.getClass();
        Method method = name.getDeclaredMethod("exec",String.class);

        System.out.println("通过 getDeclaredMethod 方式获取方法：");
        System.out.println(method);
    }
}
