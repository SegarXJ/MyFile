package com.ms08067.getMethods;

import java.lang.reflect.Method;

public class getMethods {
    public static void main(String[] args) {
        Runtime rt = Runtime.getRuntime();

        Class<?> name = rt.getClass();

        Method[] methods = name.getMethods();

        System.out.println("getMethods获取特定的方法：");
        for(Method m:methods)
            System.out.println(m);
    }
}
