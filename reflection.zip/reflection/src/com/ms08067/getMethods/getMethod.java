package com.ms08067.getMethods;

import java.lang.reflect.Method;

public class getMethod {
    public static void main(String[] args) throws NoSuchMethodException {
        Runtime rt = Runtime.getRuntime();

        Class<?> name = rt.getClass();

        Method method = name.getMethod("exec",String.class);

        System.out.println("getMethod获取特定的方法：");
        System.out.println(method);
    }
}
