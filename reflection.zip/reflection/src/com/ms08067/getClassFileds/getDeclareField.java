package com.ms08067.getClassFileds;

import com.ms08067.Student;

import java.lang.reflect.Field;

public class getDeclareField {
    public static void main(String[] args) throws NoSuchFieldException {
        Student student = new Student();

        Class<?> name = student.getClass();

        Field getDeclaredField = name.getDeclaredField("name");

        System.out.println("通过 getDeclaredField 方式获取方法：");
        System.out.println(getDeclaredField);
    }
}
