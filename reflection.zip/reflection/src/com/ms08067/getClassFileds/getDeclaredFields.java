package com.ms08067.getClassFileds;

import com.ms08067.Student;

import java.lang.reflect.Field;

public class getDeclaredFields {
    public static void main(String[] args) {
        Student student = new Student();

        Class<?> name = student.getClass();

        Field[] getDeclaredFields = name.getDeclaredFields();

        System.out.println("通过 getDeclaredFields 方式获取方法：");
        for(Field m:getDeclaredFields)
            System.out.println(m);
    }
}
