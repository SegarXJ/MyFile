package com.ms08067.getClassFileds;

import com.ms08067.Student;

import java.lang.reflect.Field;

public class getFields {
    public static void main(String[] args) {
        Student student = new Student();

        Class<?> name = student.getClass();

        Field[] getFields = name.getFields();

        System.out.println("通过 getFields 获取的方法：");
        for(Field m:getFields)
            System.out.println(m);
    }
}
