package com.ms08067.getClassFileds;

import com.ms08067.Student;

import java.lang.reflect.Field;

public class getField {
    public static void main(String[] args) throws NoSuchFieldException {
        Student student = new Student();

        Class<?> name = student.getClass();

        Field getField = name.getField("content");

        System.out.println("通过 getField 方式获取方法：");
        System.out.println(getField);
    }
}
