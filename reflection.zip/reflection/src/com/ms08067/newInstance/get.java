package com.ms08067.newInstance;
import com.ms08067.newInstance.newInstanceExample;

import java.lang.reflect.InvocationTargetException;

public class get {
    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
        Class<?> cls = Class.forName("com.ms08067.newInstance.newInstanceExample");
        // 无参数
        System.out.println("无参数构造对象第一种方法：");
        newInstanceExample no_parameters_1 = (newInstanceExample)cls.newInstance();
        System.out.println("无参数构造对象第二种方法");
        newInstanceExample no_parameters_2 = newInstanceExample.class.newInstance();
        // 有参数
        System.out.println("有参数构造对象第一种方法");
        newInstanceExample have_parameters_1 = (newInstanceExample)cls.getConstructor(String.class).newInstance("yes");
        System.out.println("有参数构造对象第二种方法");
        newInstanceExample have_parameters_2 = newInstanceExample.class.getConstructor(String.class).newInstance("yes");



    }
}
