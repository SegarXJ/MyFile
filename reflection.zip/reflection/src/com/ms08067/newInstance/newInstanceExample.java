package com.ms08067.newInstance;

public class newInstanceExample {
    public newInstanceExample(){
        System.out.println("No parameters");
    }
    public  newInstanceExample(String string){
        System.out.println("Hava parameters");
        System.out.println(string);
    }

    public String method_1(){
        return "invoke 方法调用 method_1";
    }

    public String method_2(String string){
        String result = "I'm " + string;
        System.out.println(result);
        return result;
    }
}
