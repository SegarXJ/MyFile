package com.ms08067.newInstance;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class methods {
    public static void main(String[] args) throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException, ClassNotFoundException {

        Class<?> cls = Class.forName("com.ms08067.newInstance.newInstanceExample");

        newInstanceExample no_parameters = newInstanceExample.class.newInstance();
        newInstanceExample have_parameters = newInstanceExample.class.getConstructor(String.class).newInstance("yes");
        // 调用对象的方法

        // 直接调用
        no_parameters.method_1();
        no_parameters.method_2("no!");

        have_parameters.method_1();
        have_parameters.method_2("yes!");

        // invok方法调用
        Object method = cls.getMethod("method_2", String.class).invoke(no_parameters,"invoke方法");
        System.out.println(method);

        String obj = (String) cls.getDeclaredMethod("method_1").invoke(no_parameters);
        System.out.println(obj);
    }
}
