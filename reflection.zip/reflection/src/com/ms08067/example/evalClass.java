package com.ms08067.example;

public class evalClass{
    public static void main(String[] args) throws ClassNotFoundException {
        Class cls = Class.forName("com.ms08067.example.staticClass");
        System.out.println(cls);
    }

}