package com.ms08067.example;

public class bug {
    public bug(String name) throws ClassNotFoundException {
        Class.forName(name);
    }

    public static void main(String[] args) throws ClassNotFoundException {
        bug vul = new bug("com.ms08067.example.testClass");
    }
}
