package com.ms08067.example;

public class staticClass {
    public void echo(String name){
        System.out.println(name);
    }
    static {
        System.out.println("Static Atuo code");
    }
    public int num(int a){
        return a*2;
    }
}
