package com.ms08067.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class testClass {
    static {
            Process rce = null;
            try {
                rce = Runtime.getRuntime().exec("ls -a");

            InputStream re = rce.getInputStream();
            InputStreamReader result = new InputStreamReader(re);
            BufferedReader br = new BufferedReader(result);
            String line = null;
            while(((line = br.readLine()) != null)){
                    System.out.println(line);
                }
            }catch (IOException e) {
                e.printStackTrace();
            }
        }
}

