package com.ms08067.getClass;

public class zhijie {
    public static void main(String[] args) {

        Runtime rt = Runtime.getRuntime();

        Class<?> name = rt.getClass();

        System.out.println(name);
    }
}
